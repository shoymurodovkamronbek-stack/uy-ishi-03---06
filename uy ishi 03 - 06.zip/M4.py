import os
os.system("cls")

import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, QComboBox,
    QLineEdit, QVBoxLayout, QHBoxLayout
)
from PyQt5.QtCore import Qt

class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("So'z qo'shish")
        self.resize(400, 300)
        self.setStyleSheet("background-color: #1e1e1e; color: #219466; font-family: Arial;")

        layout = QVBoxLayout()

        self.input_line_edit = QLineEdit(self)        
        self.combo = QComboBox(self)                 
        input_layout = QHBoxLayout()
        btn = QPushButton("Qo'shish", self)
        btn.clicked.connect(self.add_word)

        input_layout.addWidget(self.input_line_edit)
        input_layout.addWidget(btn)

        layout.addLayout(input_layout)
        layout.addWidget(self.combo)
        self.setLayout(layout)

    def add_word(self):                            
        soz = self.input_line_edit.text().strip()
        if soz:
            self.combo.addItem(soz)
            self.input_line_edit.clear()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Window()
    ex.show()
    sys.exit(app.exec_())