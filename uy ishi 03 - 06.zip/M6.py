import os
os.system("cls")

import sys
from PyQt5.QtWidgets import (
    QApplication, QButtonGroup, QRadioButton, QWidget, QLabel, QPushButton, QComboBox,
    QLineEdit, QVBoxLayout, QHBoxLayout, QCheckBox
)
from PyQt5.QtCore import Qt

class Masala6(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Rang tanlash")
        self.resize(300, 180)
 
        self.ranglar = {
            "Qizil":  "#F10E0E",
            "Yashil": "#16c43e",
            "Ko'k":   "#2E77DE",
        }
 
        layout = QVBoxLayout()
 
        label = QLabel("Rang tanlang:", self)
        label.setStyleSheet("font-size: 14px;")
        layout.addWidget(label)
 
        self.group = QButtonGroup(self)
        for nom, rang in self.ranglar.items():
            rb = QRadioButton(nom, self)
            rb.toggled.connect(lambda checked, r=rang: self.rang_ozgartir(checked, r))
            self.group.addButton(rb)
            layout.addWidget(rb)
 
        self.setLayout(layout)
 
    def rang_ozgartir(self, checked, rang):
        if checked:
            self.setStyleSheet(f"background-color: {rang};")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Masala6()
    ex.show()
    sys.exit(app.exec_())
#   ^_^ 