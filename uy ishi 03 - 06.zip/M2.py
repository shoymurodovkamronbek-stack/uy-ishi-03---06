import os
os.system("cls")

import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, QComboBox, QCheckBox, QRadioButton, 
    QMessageBox, QVBoxLayout, QHBoxLayout, QButtonGroup
)
from PyQt5.QtCore import Qt

class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Yo'nalishlar")
        self.resize(400, 300)

        layout = QVBoxLayout()

        self.label = QLabel("Tugmani bosing")
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setStyleSheet("font-size: 24px; color: #8b4513; font-weight: bold;")
        self.label.setStyleSheet("background-color: #8f6407; color: white; font-family: Arial; padding: 10px; border-radius: 5px;")
        btn_layout = QHBoxLayout()
        for nom in ["chapga", "o'rtaga", "o'ngga"]:
            btn = QPushButton(nom, self)
            btn.clicked.connect(lambda checked, nom=nom: self.label.setText(f"{nom} bosildi"))

            btn_layout.addWidget(btn)

        layout.addWidget(self.label)
        layout.addLayout(btn_layout)
        self.setLayout(layout)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Window()
    ex.show()
    sys.exit(app.exec_())