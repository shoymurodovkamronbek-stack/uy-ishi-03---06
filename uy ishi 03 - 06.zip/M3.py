import os
os.system("cls")

import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, QComboBox, QCheckBox, QRadioButton, 
    QMessageBox, QVBoxLayout, QHBoxLayout, QButtonGroup
)
from PyQt5.QtCore import Qt

class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Til tanlash")
        self.resize(400, 300)

        layout = QVBoxLayout()

        self.label = QLabel("Tilni tanlang")
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setStyleSheet("font-size: 24px; color: #215494; font-weight: bold;")

        self.combo = QComboBox()
        for til in ["python", "java", "c++", "javascript"]:
            self.combo.addItem(til)
        self.combo.currentTextChanged.connect(lambda: self.label.setText(f"{self.combo.currentText()} tanlandi"))

        layout.addWidget(self.label)
        layout.addWidget(self.combo)
        self.setLayout(layout)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Window()
    ex.show()
    sys.exit(app.exec_())