import os
os.system("cls")

import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, QComboBox,
    QLineEdit, QVBoxLayout, QHBoxLayout, QCheckBox
)
from PyQt5.QtCore import Qt

class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Mahsulotlar")
        self.resize(400, 300)
        self.setStyleSheet("background-color: #116473; color: #1e1e1e; font-family: Arial;")
        self.mahsulotlar = {
            "Olma  — 15 000 so'm":  15000,
            "Banan — 27 000 so'm":  27000,
            "Uzum  — 10 000 so'm": 10000,
            "Gilos  — 20 000 so'm": 20000,
            "Qulupnay — 25 000 so'm": 25000
        }

        layout = QVBoxLayout()

        self.checkboxes = []
        for nom, narx in self.mahsulotlar.items():
            cb = QCheckBox(nom, self)
            cb.stateChanged.connect(self.hisoblash)
            self.checkboxes.append((cb, narx))
            layout.addWidget(cb)
 
        self.label = QLabel("Jami: 0 so'm", self)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setStyleSheet("font-size: 15px; font-weight: bold;")
 
        layout.addWidget(self.label)
        self.setLayout(layout)
 
    def hisoblash(self):
        jami = sum(narx for cb, narx in self.checkboxes if cb.isChecked())
        self.label.setText(f"Jami: {jami:,} so'm".replace(",", " "))

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Window()
    ex.show()
    sys.exit(app.exec_())