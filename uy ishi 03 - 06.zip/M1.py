import os
os.system("cls")

import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, QComboBox, QCheckBox, QRadioButton, 
    QMessageBox, QVBoxLayout, QHBoxLayout, QButtonGroup
)
from PyQt5.QtCore import Qt

class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Tugmalar")
        self.resize(400, 300)

        layout = QVBoxLayout()
        for nom in ["Birimchi tugma", "Ikkinchi tugma", "Uchinchi tugma"]:
            btn = QPushButton(nom)
            btn.clicked.connect(lambda checked, nom=nom: self.show_message(nom))
            layout.addWidget(btn)
        self.setLayout(layout)

    def show_message(self, nom):
        print(f"{nom} bosildi")
        QMessageBox.information(self, "Tugma bosildi", f"{nom} bosildi")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Window()
    ex.show()
    sys.exit(app.exec_())